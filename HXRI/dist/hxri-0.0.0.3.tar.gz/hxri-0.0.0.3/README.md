# HXRI

py -3 setup.py sdist bdist_wheel
py -3 -m pip install dist/hxri-0.0.0.3.tar.gz